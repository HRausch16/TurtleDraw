# Project: TurtleDraw
Repository for "Turtle Draw Assignment"

Name: Hannah Rausch
Project: Turtle Draw
Lewis Email: hannahirausch@lewisu.edu
Turtle Draw was developed by Wally Feurzeig, Seymour Papert, and Cynthia Solomon in 1967.

Execution instructions: Open python file (TurtleDraw_hr.py) with any terminal window using python 3.
Required files: TurtleDraw_hr.py and turtle-draw.txt